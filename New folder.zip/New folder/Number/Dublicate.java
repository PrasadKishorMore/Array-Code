
import java.util.HashSet;
import java.util.Scanner;


public class Dublicate{


    public static void main(String[] args){

        Scanner s = new Scanner(System.in);
        System.out.println("Inter valid digit:");
        int num =s.nextInt();

        HashSet<Integer> h = new HashSet();

        while(num > 0){
            int digit = num%10;

            if(h.contains(digit)){
                System.out.println("digit dublicate:"+digit);
            }else{
                h.add(digit);
            }

            num /= 10;
        }

        
    }
}