
import java.util.Scanner;
public class Factorial{

    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);
        System.out.println("inter the digit into 1 to 10:");
        int num  = s.nextInt();

        int sum =1;

        for(int i=1; i<=num; i++){

            sum = sum*i;

        }

        System.err.println(sum);


    }
}