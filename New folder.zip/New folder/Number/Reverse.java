public class Reverse{



    public static void main(String[] args){

        int num = 123;


        String s ="";

        while(num > 0){

            int digit = num%10;

            String str = Integer.toString(digit);
            s += str;

            num = num/10;

        }

        int newNUM = Integer.parseInt(s);
        System.out.println(newNUM);
    }
}