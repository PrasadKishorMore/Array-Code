

import java.util.Scanner;
public class Largeval{


    public static void main(String[] args) {
        
        Scanner s = new Scanner(System.in);

        System.out.println("provide valid number:");

        int  num =  s.nextInt();

        int largeNum = 1;
         
         while(num > 0){
            
            int digit = num%10;

            if(largeNum < digit){
                largeNum = digit;
            }

            num /= 10;

         }

         System.out.println("larges number into digit:"+ largeNum);

    }
}