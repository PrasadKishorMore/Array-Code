public class MaxSumSubarrayOneDeletion {
    public static int maximumSum(int[] arr) {
        int n = arr.length;
        int maxEndHere = arr[0];      // max sum ending here without deletion
        int maxEndHereDeleted = 0;    // max sum ending here with one deletion
        int result = arr[0];

        for (int i = 1; i < n; i++) {
            maxEndHereDeleted = Math.max(maxEndHere, maxEndHereDeleted + arr[i]);
            maxEndHere = Math.max(arr[i], maxEndHere + arr[i]);
            result = Math.max(result, Math.max(maxEndHere, maxEndHereDeleted));
        }

        return result;
    }

    public static void main(String[] args) {
        int[] arr = {1, -2, 0, 3};
        System.out.println("Maximum sum with at most one deletion: " + maximumSum(arr));
    }
}
