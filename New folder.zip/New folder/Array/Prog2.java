
public class Prog2{

   //sorting of arrays 


    public void mergesort(int arr[], int left , int right){

        if(left < right){

            int mid = (left + right)/2;

            mergesort(arr, left, mid);
            mergesort(arr, mid+1, right);

            mergesortcheck(arr,left, mid, right);
        }
    }

    @SuppressWarnings("ManualArrayToCollectionCopy")
    public void mergesortcheck(int arr[], int left , int mid, int right){
         
              // ✅ fixed: correct array size
    int temp[] = new int[right - left + 1];

    int i = left;
    int j = mid + 1;
    int k = 0;

    // ✅ fixed: correct conditions (<= instead of <)
    while(i <= mid && j <= right){
        if(arr[i] < arr[j]){
            temp[k++] = arr[i++];
        } else {
            temp[k++] = arr[j++];
        }
    }
    
    while(i <= mid){
        temp[k++] = arr[i++];
    }

    while(j <= right){
        temp[k++] = arr[j++];
    }
    
    // ✅ copy merged values back to original array
    for(int p = 0; p < temp.length; p++){
        arr[left + p] = temp[p];
    }

    // ✅ optional: print merged portion for debugging
    System.err.print("Merged (" + left + "," + right + "): ");
    for(int p = 0; p < temp.length; p++){
        System.err.print(temp[p] + " ");
    }
    System.err.println();
    }
    public static void main(String[] args) {
        
    //   int arr[] = new int[5];
        //  Scanner s = new Scanner(System.in);
        //  System.out.println("Inter five number for sorting:");

       //1) bubble sort

        //  for(int i=0; i<5; i++){

        //      arr[i] = s.nextInt();
        //  }

        //  for(int p=0; p<arr.length-1; p++){

        //     for(int q=0; q<arr.length-p-1; q++){

        //         if( arr[q] > arr[q+1]){
        //             int temp = arr[q];
        //             arr[q] = arr[q+1];
        //             arr[q+1]  = temp;
        //         }
        //     }
        //  }

        //  for(int val : arr){
        //     System.out.print(val +",");
        //  }

       

          int arr[] = {2,4,6,1,0};
          int left =0;
          int right = arr.length-1;

          Prog2 p = new Prog2();
          p.mergesort(arr, left, right);
          
  

        //2) selection sort

        //   for(int i=0 ; i<arr.length-1; i++){

        //     for(int j=0; j<arr.length-1-i; j++){

        //         if(arr[j] > arr[j+1]){

        //             int temp = arr[j];
        //             arr[j] = arr[j+1];
        //             arr[j+1] = temp;
        //         }
        //     }
        //   }


        //   for(int val : arr){
        //     System.err.print(val +",");
        //   }


        // for(int i=0; i<arr.length-1; i++){

        //     int minindex = i;

        //     for(int j=i+1; j<arr.length; j++){

        //         if(arr[j] < arr[minindex]){
                   
        //            minindex = j;
        //         }
        //     }

        //     if(minindex != i){

        //         int temp = arr[i];
        //         arr[i] = arr[minindex];
        //         arr[minindex] = temp;

        //     }
        // }

        //3)  insertion sort
       
    //    for(int i=1; i<arr.length; i++){

    //        int key = arr[i];
    //        int j = i-1;

    //        while(j>=0 && arr[j] > key){
               
    //            arr[j+1] = arr[j];

    //            j =j-1;

    //        }

    //        arr[j+1] = key;
    //    }

    //     for(int val : arr){

    //         System.err.print(val+",");
    //     }

    }
}