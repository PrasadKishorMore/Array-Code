public class Prog1{



    public static void main(String[] args) {
        
        //move all zero AS LAST of array

        int arr[] = {1,0,3,0,5};

        int l = arr.length;

        int temp[] = new int[l];

        int i=0;

        for(int val : arr){

            if(val != 0){
                temp[i++] = val;
            }
        }

        i=0;
        for(int p=0; p<l ; p++){

            arr[p] = temp[i++];
        }

        for(int num : arr){
            System.err.print(num +",");
        }


    }
}