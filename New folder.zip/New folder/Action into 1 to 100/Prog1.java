

public class Prog1{

    //print fibonacci series into 1 to 100

    public static void main(String[] args) {
        
       System.out.println("0");
        System.out.println("1");
       for(int i=2; i<=100; i++){
          
         int num =(i-1)+(i-2);
          System.out.println(num);
       }

    }
}